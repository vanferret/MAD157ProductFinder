//
//  CartItems.swift
//  ProductFinder
//
//  Created by student on 7/17/20.
//  Copyright © 2020 HarvardInc. All rights reserved.
//

import Foundation
import UIKit

class CartItems {
    static let sharedCartItems = CartItems()
    private(set) var items:[String]
    
    init() {
        let defaults = UserDefaults.standard
        let storedItems = defaults.object(forKey: "items") as? [String]
        items = storedItems != nil ? storedItems! : []
    }
    
    func hasItem(itemName: String) -> Bool {
        return items.contains(itemName)
    }
    
    func addItem(itemName: String) {
        if !items.contains(itemName) {
            items.append(itemName)
            saveItems()
        }
    }
    
    func removeItem(itemName: String) {
        if let index = items.firstIndex(of: itemName) {
            items.remove(at: index)
            saveItems()
        }
    }
    
    private func saveItems() {
        let defaults = UserDefaults.standard
        defaults.set(items, forKey: "items")
        defaults.synchronize()
    }
    
    func moveItem(fromIndex from: Int, toIndex to: Int) {
        let item = items[from]
        items.remove(at: from)
        items.insert(item, at: to)
        saveItems()
    }
    
}
