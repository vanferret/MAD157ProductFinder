//
//  SecondScreenViewController.swift
//  ProductFinder
//
//  Created by student on 7/16/20.
//  Copyright © 2020 HarvardInc. All rights reserved.
//

import UIKit

class SecondScreenViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var cartItems: [String] = []
    var productMaster: Products = Products()
    
    // Cell Identifier
     let cellTableIdentifier = "MonkeyBusiness"
    
    @IBOutlet weak var tableView: UITableView!
    
    // Define a dictionary to hold all of my items
//    var cart: [String:[String:String]] = [:]
   
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // Temporarily add an item just to be there
//        var cartItem:[String:String] = [:]
        //name, smallPictureName, largePictureName, descriptionFileName, price
//        cartItem["name"] = "Romaine Lettuce"
//        cartItem["smallPictureName"] = "25romaine"
//        cartItem["largePictureName"] = "300romaine"
//        cartItem["descriptionFileName"] = "romaine"
//        cartItem["price"] = "3"
//        cart["Romaine Lettuce"] = cartItem
        // "name" : "Romaine Lettuce" , "smallPictureName" :  "25romaine" , "largePictureName" : "300romaine" , "descriptionFileName" : "romaine", "price" : 3
        tableView.register(TableCell.self, forCellReuseIdentifier: cellTableIdentifier)
        let xib = UINib(nibName: "TableCell2", bundle: nil)
        
        tableView.register(xib, forCellReuseIdentifier: cellTableIdentifier)
        tableView.rowHeight = 66
        
        navigationItem.rightBarButtonItem = editButtonItem
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        cartItems = CartItems.sharedCartItems.items
            tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //print(cartItems.count)
        return cartItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell( withIdentifier: cellTableIdentifier, for: indexPath) as! TableCell
        
        let rowName = cartItems[indexPath.row]
        
        let rowData = productMaster.getProductByName(name: rowName)
        
        if (rowData != nil)  {
        cell.productItem = rowData!.name
        cell.productPrice = rowData!.price
        cell.productPicture = UIImage(named: "\(rowData!.smallPictureName).png")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "detail2", sender: nil)
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        let detailVC = segue.destination as! ItemViewController
        let row = tableView.indexPathForSelectedRow!.row
    
        let rowName = cartItems[row]
        let rowData = productMaster.getProductByName(name: rowName)
        
        detailVC.productName = rowData!.name
        detailVC.productimage = UIImage(named: "\(rowData!.largePictureName).png") ?? UIImage(named: "question.png")!
        // If we got this far, it's there
        detailVC.inCart = true
        // Get URL
//    guard let url = Bundle.main.url(forResource: productMaster.getProduct(index: row).descriptionFileName, withExtension: "html") else{
//        return
//    }
    
    // Grab Data
//    guard let data = try? Data(contentsOf: url) else {
//        return
//
//    }
    
    // Convert Data into String for passing
    //let str = String(decoding: data, as: UTF8.self)
//    if let attributedString = try? NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html], documentAttributes: nil) {
//        detailVC.pDesc = attributedString
//    }

    }
    

}
