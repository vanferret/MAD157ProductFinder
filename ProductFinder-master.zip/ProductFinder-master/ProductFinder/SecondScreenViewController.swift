//
//  SecondScreenViewController.swift
//  ProductFinder
//
//  Created by student on 7/16/20.
//  Copyright © 2020 HarvardInc. All rights reserved.
//

import UIKit

class SecondScreenViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var cartItems: [String] = []
    var mycartItems: [String:String] = [:]
    var productMaster: Products = Products()
    
    // Cell Identifier
     let cellTableIdentifier = "MonkeyBusiness"
    
    @IBOutlet weak var tableView: UITableView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // Reusing the xib so it is familiar
        tableView.register(TableCell.self, forCellReuseIdentifier: cellTableIdentifier)
        let xib = UINib(nibName: "TableCell2", bundle: nil)
        
        tableView.register(xib, forCellReuseIdentifier: cellTableIdentifier)
        tableView.rowHeight = 66
        
        // We can do some setup here if we want this to be active, otherwise user can toggle now
        // navigationItem.rightBarButtonItem = editButtonItem
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        cartItems = CartItems.sharedCartItems.items
            tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cartItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell( withIdentifier: cellTableIdentifier, for: indexPath) as! TableCell
        
        let rowName = cartItems[indexPath.row]
        
        let rowData = productMaster.getProductByName(name: rowName)
        
        if (rowData != nil)  {
        cell.productItem = rowData!.name
        cell.productPrice = rowData!.price
        cell.productPicture = UIImage(named: "\(rowData!.smallPictureName).png")
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "detail2", sender: nil)
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.... kind of
        let detailVC = segue.destination as! ItemViewController
        let row = tableView.indexPathForSelectedRow!.row
    
        // We can probably change some of this to function off of a dictionary
        // But I had to be able to access a dictionary for the cart, so needed to add a get by name func
        let rowName = cartItems[row]
        let rowData = productMaster.getProductByName(name: rowName)
        
        
        detailVC.productName = rowData!.name
        detailVC.productimage = UIImage(named: "\(rowData!.largePictureName).png") ?? UIImage(named: "question.png")!
        // If we got this far, it's there
        detailVC.inCart = true
        detailVC.productQuantityType = rowData!.unit
        detailVC.productPrice = rowData!.price
        
        // If we have an item in the cart, we'll make sure it pulls up with its quantity
        if CartItems.sharedCartItems.hasItemDict(itemName: rowName) {
            detailVC.productQuantityVal = CartItems.sharedCartItems.myitems[rowName]!["quantity"]!
        } else {
            detailVC.productQuantityVal = "0"
        }
        // Everything commented below blows up and breaks anything after it
        // NEEDS ATTENTION!!!!
        
        // Get URL
//    guard let url = Bundle.main.url(forResource: productMaster.getProduct(index: row).descriptionFileName, withExtension: "html") else{
//        return
//    }
    
    // Grab Data
//    guard let data = try? Data(contentsOf: url) else {
//        return
//
//    }
    
    // Convert Data into String for passing
    //let str = String(decoding: data, as: UTF8.self)
//    if let attributedString = try? NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html], documentAttributes: nil) {
//        detailVC.pDesc = attributedString
//    }

    }
    

}
