//
//  PriceView.swift
//  ProductFinder
//
//  Created by Aaron Kinney on 4/19/20.
//  Copyright © 2020 HarvardInc. All rights reserved.
//

import SwiftUI

struct PriceView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct PriceView_Previews: PreviewProvider {
    static var previews: some View {
        PriceView()
    }
}
