//
//  CartItems.swift
//  ProductFinder
//
//  Created by student on 7/17/20.
//  Copyright © 2020 HarvardInc. All rights reserved.
//

import Foundation
import UIKit

class CartItems {
    static let sharedCartItems = CartItems()
    private(set) var items:[String]
    // 2020-07-26 - going to see if we can update a dictionary as well
    private(set) var myitems: [String:[String:String]] = [:]
    
    init() {
        let defaults = UserDefaults.standard
        let storedItems = defaults.object(forKey: "items") as? [String]
        let storedDict = defaults.object(forKey: "itemsN") as? [String:[String:String]]
        items = storedItems != nil ? storedItems! : []
        myitems = storedDict != nil ? storedDict! : [:]
    }
    
    func hasItem(itemName: String) -> Bool {
        return items.contains(itemName)
    }
    
    func hasItemDict(itemName: String) -> Bool {
        return myitems.keys.contains(itemName)
    }
    
    func addItem(itemName: String,itemQuantity: String) {
        if !items.contains(itemName) {
            items.append(itemName)
            saveItems()
        }
        if myitems.keys.contains(itemName) {
            myitems.removeValue(forKey: itemName)
            myitems[itemName] = ["quantity":itemQuantity]
        } else {
            myitems[itemName] = ["quantity":itemQuantity]
        }
    }
    
    func removeItem(itemName: String) {
        if let index = items.firstIndex(of: itemName) {
            items.remove(at: index)
            saveItems()
        }
        if myitems.keys.contains(itemName) {
            myitems.removeValue(forKey: itemName)
        }
    }
    
    private func saveItems() {
        let defaults = UserDefaults.standard
        defaults.set(items, forKey: "items")
        defaults.set(myitems, forKey: "itemsN")
        defaults.synchronize()
    }
    
    func moveItem(fromIndex from: Int, toIndex to: Int) {
        let item = items[from]
        items.remove(at: from)
        items.insert(item, at: to)
        saveItems()
    }
    
}
