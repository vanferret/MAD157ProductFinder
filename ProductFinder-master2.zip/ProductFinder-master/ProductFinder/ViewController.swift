import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
     
    private var cartItems: CartItems!
    
     // Cell Identifier
     let cellTableIdentifier = "MonkeyBusiness"
    
    @IBOutlet weak var tableView: UITableView!
   
    // Product Master
    var productMaster: Products = Products()
    var arrayTitles:[String] = []
    
    
    // Did Load Logic and registration of TableCell
    override func viewDidLoad() {
        super.viewDidLoad()
        
        productMaster = Products(fileName: "product")
        
        // Do any additional setup after loading the view, typically from a nib.
        tableView.register(TableCell.self, forCellReuseIdentifier: cellTableIdentifier)
        let xib = UINib(nibName: "TableCell2", bundle: nil)
        
        tableView.register(xib, forCellReuseIdentifier: cellTableIdentifier)
        tableView.rowHeight = 66
        addNavBarImage()
        cartItems = CartItems.sharedCartItems
        arrayTitles = sectionIndexTitles()!
    }

 
    // MARK: Table View Data Source Methods
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return arrayTitles.count
    }
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//
//        return productMaster.count
//
//    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let key = arrayTitles[section]
        let secCount = sectionCounts(inLetter: key)!
        return secCount
    }
    
//    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
//        return arrayTitles[section]
//    }
    
    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return arrayTitles
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell( withIdentifier: cellTableIdentifier, for: indexPath) as! TableCell
        // This is very backwards because we have sections, but the objects don't follow, so we need to
        // add up everything that came before to get the index from the overall list
        let section = indexPath.section
        var count = 0
        
        if section > 0 {
            for index in 0...max(0,section-1){
                let key = arrayTitles[index]
                count += sectionCounts(inLetter: key)!
            }
        }
        // And finally add the row number from this section
        count += indexPath.row
        
        let rowData = productMaster.getProduct(index: count)
        
        cell.productItem = rowData.name
        cell.productPrice = rowData.price
        cell.productPicture = UIImage(named: "\(rowData.smallPictureName).png")
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "detail", sender: nil)
        tableView.deselectRow(at: indexPath, animated: true)
        
    }
    
    
    // MARK: - Navigation override
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       // Get the new view controller using [segue destinationViewController].
       // Pass the selected object to the new view controller.
        if segue.identifier == "detail" {
            let detailVC = segue.destination as! ItemViewController
            let row = tableView.indexPathForSelectedRow!.row
            let pName = productMaster.getProduct(index: row).name
            
            detailVC.productName = pName
            detailVC.productimage = UIImage(named: "\(productMaster.getProduct(index: row).largePictureName).png") ?? UIImage(named: "question.png")!
            detailVC.inCart = cartItems.hasItem(itemName: pName)
            detailVC.productQuantityType = productMaster.getProduct(index: row).unit
            detailVC.productPrice = productMaster.getProduct(index: row).price
            detailVC.productMaster = productMaster
           
            // If we have an item in the cart, we'll make sure it pulls up with its quantity
            // No matter where we enter from
            if CartItems.sharedCartItems.hasItemDict(itemName: pName) {
                detailVC.productQuantityVal = CartItems.sharedCartItems.myitems[pName]!["quantity"]!
            } else {
                detailVC.productQuantityVal = "0"
            }
            
            // Everything commented below blows up and breaks anything after it
            // NEEDS ATTENTION!!!!
            
            // Get URL
            //            guard let url = Bundle.main.url(forResource: productMaster.getProduct(index: row).descriptionFileName, withExtension: "html") else{
//                return
//            }
//
//            Grab Data
//            guard let data = try? Data(contentsOf: url) else {
//                return
//
//            }
            
//          Convert Data into String for passing
//          let str = String(decoding: data, as: UTF8.self)

//            if let attributedString = try? NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html], documentAttributes: nil) {
//                detailVC.pDesc = attributedString
//            }
            //detailVC.productDescription = str
    
            
        } else {

            // If we are going directly to the cart, we just have to pass the basics
            let detailVC = segue.destination as! SecondScreenViewController
            detailVC.title = "Shopping Cart"
            detailVC.cartItems = cartItems.items
            detailVC.productMaster = productMaster
        }
    }

    
    func sectionIndexTitles() -> [String]? {
        var arrayTitles:[String] = []
        for item in productMaster.productList{
            let firstLetter = String(item.name.prefix(1))
            
            if !arrayTitles.contains(firstLetter){
                arrayTitles.append(firstLetter)
            }
        }
        
        return arrayTitles.sorted()
    }
    
    func sectionCounts(inLetter: String) -> Int? {
        var count: Int = 0
        for item in productMaster.productList{
            let firstLetter = String(item.name.prefix(1))
            
            if (firstLetter == inLetter){
                count += 1
            }
        }
        
        return count
    }
 
    func addNavBarImage() {

        let navController = navigationController!

        let image = UIImage(named: "piscasawnoflower.png")
        let imageView = UIImageView(image: image)

        let bannerWidth = navController.navigationBar.frame.size.width
        let bannerHeight = navController.navigationBar.frame.size.height
        

        let bannerX = bannerWidth / 2 - (image?.size.width)! / 2
        let bannerY = bannerHeight / 2 - (image?.size.height)! / 2

        imageView.frame = CGRect(x: bannerX, y: bannerY, width: bannerWidth, height: bannerHeight)
        imageView.contentMode = .scaleAspectFit

        navigationItem.titleView = imageView
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Cart", style: .plain, target: self, action: #selector(addTapped))
    }
    
    @objc func addTapped() {
        // Add the manual segue with a function because we aren't using a typical table object
        self.performSegue(withIdentifier: "myCart", sender: self)
        
    }
    
}
